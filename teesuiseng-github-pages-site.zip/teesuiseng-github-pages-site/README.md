# Tee Laboratory — Static Site

This repository hosts a static website for the Tee Laboratory (migrated from Wix) using GitHub Pages.

## Deploy (GitHub Pages)
1. Create a repo named `teesuiseng.github.io` under the GitHub account `teesuiseng`
2. Upload these files to the repo root (or `git push`)
3. In **Settings → Pages**, set:
   - Source: Deploy from a branch
   - Branch: main
   - Folder: / (root)

Your site will be live at: https://teesuiseng.github.io/
